< !DOCTYPE html >
    <
    html >

    <
    head >
    <!-- Google Tag Manager -->
    <
    script >
    (function(w, d, s, l, i) {
        w[l] = w[l] || [];
        w[l].push({
            'gtm.start': new Date().getTime(),
            event: 'gtm.js'
        });
        var f = d.getElementsByTagName(s)[0],
            j = d.createElement(s),
            dl = l != 'dataLayer' ? '&l=' + l : '';
        j.async = true;
        j.src =
            'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
        f.parentNode.insertBefore(j, f);
    })(window, document, 'script', 'dataLayer', 'GTM-NW9WSK9'); <
/script>
<!-- End Google Tag Manager -->


<
meta http - equiv = "ContenType"
content = "text/html; charset=UTF-8" / >
    <
    meta name = "viewport"
content = "width=device-width, initial-scale=1" >
    <
    title > Smartcode Gold class < /title> <
    meta name = "keywords"
content = "" >
    <
    meta name = "" >
    <
    link rel = "icon"
href = "images/favicon.png"
type = "image/png"
sizes = "16x16" >
    <
    link rel = "stylesheet"
href = "https://use.fontawesome.com/releases/v5.3.1/css/all.css" >
    <
    link href = "https://owlcarousel2.github.io/OwlCarousel2/assets/owlcarousel/assets/owl.carousel.min.css"
rel = "stylesheet" >
    <
    link href = "https://owlcarousel2.github.io/OwlCarousel2/assets/owlcarousel/assets/owl.theme.default.min.css"
rel = "stylesheet" >

    <
    link href = "css/bootstrap.min.css"
rel = "stylesheet"
type = "text/css" >
    <
    link href = "css/bootstrap-theme.min.css"
rel = "stylesheet"
type = "text/css" >
    <
    link href = "css/style.css"
rel = "stylesheet"
type = "text/css" >
    <!--<link href="lightbox/lighbox.css" rel='stylesheet' type='text/css'>-->
    <
    link rel = "stylesheet"
href = "css/hover.css" >
    <
    link rel = "stylesheet"
href = "css/animate.min.css" >

    <
    link rel = "stylesheet"
href = "css/flaticon.css" >
    <
    link rel = "stylesheet"
href = "css/form.css" >


    <
    link rel = "stylesheet"
href = "https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" / >
    <
    script src = "js/jquery-3.3.1.min.js" > < /script>

    <
    link href = "https://fonts.googleapis.com/css?family=Questrial&display=swap"
rel = "stylesheet" >
    <!-- waybeolib -->
    <
    link rel = "stylesheet"
href = "waybeolib/css/intlTelInput.css" >
    <
    link rel = "stylesheet"
href = "waybeolib/css/normalpop.css" >
    <!-- waybeolib -->

    <
    /head>

    <
    body >

    <!-- Google Tag Manager (noscript) -->
    <
    noscript > < iframe src = "https://www.googletagmanager.com/ns.html?id=GTM-NW9WSK9"
height = "0"
width = "0"
style = "display:none;visibility:hidden" > < /iframe></noscript >
    <!-- End Google Tag Manager (noscript) -->
    <
    header id = "home" >
    <
    nav class = "navbar navbar-default"
id = "hide-menu" >
    <
    div class = "container" >
    <!-- Brand and toggle get grouped for better mobile display -->
    <
    div class = "col-md-1" >
    <
    div class = "navbar-header" >
    <
    button type = "button"
class = "navbar-toggle collapsed"
data - toggle = "collapse"
data - target = "#bs-example-navbar-collapse-1"
aria - expanded = "false" >
    <
    span class = "sr-only" > Toggle navigation < /span> <
    span class = "icon-bar" > < /span> <
    span class = "icon-bar" > < /span> <
    span class = "icon-bar" > < /span> <
    /button> <
    a class = "navbar-brand"
href = "javascript:void(0)" >
    <
    img src = "images/logo.png" >
    <
    img class = "new visible-xs"
src = "images/logo2.png"
style = " width: 68px;float: left;margin-top: 0px;margin-left: 10px;" >
    <
    /a> <
    /div> <
    /div>

    <
    div class = "col-md-10" >
    <!-- Collect the nav links, forms, and other content for toggling -->
    <
    div class = "collapse navbar-collapse"
id = "bs-example-navbar-collapse-1" >

    <
    ul class = "nav navbar-nav navbar-right" >
    <
    li > < a href = "#home"
class = "m-link" > Home < /a></li >
    <
    li > < a href = "#atmosphere"
class = "m-link" > Overview < /a></li >
    <
    li > < a href = "#configuration"
class = "m-link" > Configuration < /a></li >
    <
    li > < a href = "#parkamenities"
class = "m-link" > Amenities < /a></li >
    <
    li > < a href = "#gallery"
class = "m-link" > Gallery < /a></li >
    <
    li > < a href = "#location"
class = "m-link" > Location < /a></li >
    <!-- <li><a href="#aboutus" class="m-link">About Us</a></li> -->
    <!-- <li><a href="#tour" class="m-link">Virtual Tour</a></li> -->
    <
    li > < a href = "#contactus"
class = "m-link" > Contact Us < /a></li >

    <
    /ul> <
    /div><!-- /.navbar - collapse -->
    <
    /div><!-- /.container - fluid-- >
    <
    div class = "col-md-1 hidden-xs" >
    <
    div class = "navbar-header" >

    <
    a class = "navbar-brand"
href = "javascript:void(0)" >

    <
    img class = "new"
src = "images/logo2.png"
style = "position: relative;right: 0px;width: 101px;" >
    <
    /a> <
    /div> <
    /div> <
    /div> <
    /nav> <
    /header>

    <
    section class = "sec-bannerform visible-xs" >
    <
    div id = "banner-form" >
    <
    div class = "interested-form"
style = "display: block;" >
    <!--<button type="button" class="interested-div-close"><i class="fa fa-times" aria-hidden="true"></i></button>-->
    <
    form id = "iam-interested"
method = "post"
name = "iam-interested"
action = "thank-you.php"
novalidate = "novalidate"
onsubmit = "return save_landing_pageinfo('iam-interested');" >
    <!-- Form Title -->
    <
    div class = "form-heading text-center" >
    <
    h3 class = "title" > Get In Touch < /h3> <
    p class = "title-description" > Enter Your Details Below < /p> <
    /div>
    <!-- First & Last Name -->
    <
    div class = "form-group col-md-12 pd" >
    <
    div class = "input-group" >
    <
    div class = "input-group-addon" > < i class = "fa fa-user form-ico"
aria - hidden = "true" > < /i></div >
    <
    input type = "text"
class = "form-control"
name = "fname"
placeholder = "Name" >
    <
    input type = "hidden"
name = "source"
value = "Get In Touch"
id = "source" >
    <
    /div> <
    label
for = "fname"
generated = "true"
class = "error" > < /label> <
    /div> <
    div class = "form-group col-md-12 pd" >
    <
    div class = "input-group" >
    <
    div class = "input-group-addon"
style = "padding-right: 15px; padding-left: 15px;" > < i
class = "fa fa-mobile form-ico"
aria - hidden = "true" > < /i> <
    /div> <
    input type = "number"
class = "form-control"
placeholder = "Mobile"
name = "mobile"
required = "" >
    <
    /div> <
    label
for = "mobile"
generated = "true"
class = "error" > < /label> <
    /div>

    <
    div class = "form-group col-md-12 pd" >
    <
    div class = "input-group" >
    <
    div class = "input-group-addon" > < i class = "fa fa-envelope"
aria - hidden = "true" > < /i></div >
    <
    input type = "email"
class = "form-control"
name = "email"
placeholder = "Email" >
    <
    /div> <
    label
for = "email"
generated = "true"
class = "error" > < /label> <
    /div> <
    div class = "col-md-12" >
    <
    p class = "form-disc" >
    By submitting your details you agree to the Terms & amp;
Conditions
<!-- <a href="terms-and-conditions.php" target="_blank" title="Terms of use">Terms &amp;
Conditions < /a> --> <
    /p> <
    /div>

    <!-- submit Button -->
    <
    div class = "row" >
    <
    div class = "col-md-12" >
    <
    button class = "adam-button"
type = "submit" > SUBMIT < /button> <
    /div> <
    /div> <
    /form> <
    /div> <
    /div> <
    /section>
    <!-- <section class="sec-bannerform">
    <
    div id = "banner-form" >
    <
    div class = "interested-form"
style = "display: block;" > -->
    <!-- <button type="button" class="interested-div-close"><i class="fa fa-times" aria-hidden="true"></i></button> -->
    <!-- <form id="iam-interested" method="post" name="iam-interested" action="thank-you.php" onsubmit="return save_landing_pageinfo('iam-interested');" novalidate="novalidate"> -->
    <!-- Form Title -->
    <!-- <div class="form-heading text-center">
    <
    h3 class = "title" > Get In Touch < /h3> <
    p class = "title-description" > Enter Your Details Below < /p> <
    /div> -->
    <!-- First & Last Name -->
    <!-- <div class="form-group col-md-12 pd">
    <
    div class = "input-group" >
    <
    div class = "input-group-addon" > < i class = "fa fa-user form-ico"
aria - hidden = "true" > < /i></div >
    <
    input type = "text"
class = "form-control"
name = "fname"
placeholder = "Name" >
    <
    input type = "hidden"
name = "source"
value = "Get In Touch"
id = "source" >
    <
    /div> <
    label
for = "fname"
generated = "true"
class = "error" > < /label> <
    /div> <
    div class = "form-group col-md-12 pd" >
    <
    div class = "input-group" >
    <
    div class = "input-group-addon"
style = "padding-right: 15px; padding-left: 15px;" > < i class = "fa fa-mobile form-ico"
aria - hidden = "true" > < /i> <
    /div> <
    input type = "number"
placeholder = "Mobile"
name = "mobile"
required = "" >
    <
    /div> <
    label
for = "mobile"
generated = "true"
class = "error" > < /label> <
    /div>

    <
    div class = "form-group col-md-12 pd" >
    <
    div class = "input-group" >
    <
    div class = "input-group-addon" > < i class = "fa fa-envelope"
aria - hidden = "true" > < /i></div >
    <
    input type = "email"
class = "form-control"
name = "email"
placeholder = "Email" >
    <
    /div> <
    label
for = "email"
generated = "true"
class = "error" > < /label> <
    /div> -->

    <!-- submit Button -->
    <!-- <div class="row">
    <
    div class = "col-md-12" >
    <
    button class = "adam-button"
type = "submit" > SUBMIT < /button> <
    /div> <
    /div> <
    /form> <
    /div> <
    /div> <
    /section> -->


    <
    div id = "carousel-example-generic"
class = "carousel slide carousel-fade"
data - ride = "carousel" >
    <
    ol class = "carousel-indicators" >
    <!-- <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <
    li data - target = "#carousel-example-generic"
data - slide - to = "1"
class = "" > < /li> <
    li data - target = "#carousel-example-generic"
data - slide - to = "2"
class = "" > < /li> --> <
    /ol> <
    div class = "carousel-inner"
role = "listbox" >

    <
    div class = "item active" >
    <
    img src = "images/slider/WEB1.jpg"
alt = ""
class = "hidden-xs" >
    <
    img src = "images/slider/Mobile-3.jpg"
alt = ""
class = "visible-xs" >
    <
    /div>

    <
    div class = "item" >
    <
    img src = "images/slider/WEB-3.jpg"
alt = ""
class = "hidden-xs" >
    <
    img src = "images/slider/Mobile-1.jpg"
alt = ""
class = "visible-xs" >
    <
    /div> <
    div class = "item" >
    <
    img src = "images/slider/WEB-2.jpg"
alt = ""
class = "hidden-xs" >
    <
    img src = "images/slider/Mobile-4.jpg"
alt = ""
class = "visible-xs" >
    <
    /div>

    <
    div class = "item" >
    <
    img src = "images/slider/WEB-4.jpg"
alt = ""
class = "hidden-xs" >
    <
    img src = "images/slider/Mobile-2.jpg"
alt = ""
class = "visible-xs" >
    <
    /div>


    <
    /div> <
    a class = "left carousel-control"
href = "#carousel-example-generic"
role = "button"
data - slide = "prev" >
    <
    span class = "glyphicon glyphicon-chevron-left"
aria - hidden = "true" > < /span> <
    span class = "sr-only" > Previous < /span> <
    /a> <
    a class = "right carousel-control"
href = "#carousel-example-generic"
role = "button"
data - slide = "next" >
    <
    span class = "glyphicon glyphicon-chevron-right"
aria - hidden = "true" > < /span> <
    span class = "sr-only" > Next < /span> <
    /a> <
    /div>

    <
    section class = "glob-sec"
style = "text-align: center;"
id = "atmosphere" >
    <
    div class = "container" >
    <!-- <img class="head-icon wow fadeInUp" data-wow-duration="1s" data-wow-delay="1s" src="images/head-icon.png"> -->
    <
    h2 class = "sec-head head-center wow fadeInUp"
data - wow - duration = "1s"
data - wow - delay = "0.5s" >
    Overview < /h2>
    <!-- <h3 class="sub-head">A lifestyle that seamlessly co-exists with 1300+ species of flora and fauna</h3> -->
    <
    div class = "head-line" > < /div>


    <
    div class = "overview-sec" >


    <
    div class = "col-md-12 col-xs-12"
data - aos = "fade-left"
data - aos - delay = "200"
data - aos - duration = "1000" >
    <!-- <img class="over-logo" src="images/Ajmera-Nucleus_Logo.png" data-aos="zoom-in" data-aos-delay="1000"
    data - aos - duration = "1000" > -->
    <
    p class = "text-center" > Sonawane Smart Code: Gold Class is where your lifestyle will elevate
to the next level.Enjoy the convenience at your fingertips that comes
with home automation.Explore various ways to rejuvenate amidst a host of thoughtful amenities planned on three different levels.Experience
comfortable commute thanks to a location that offers excellent connec
tivity.Smart Code: Gold Class is all about complete living. < /p> <
    /div>

    <
    div class = "col-md-12 col-xs-12"
data - aos = "fade-left"
data - aos - delay = "200"
data - aos - duration = "1000" >
    <
    div class = "col-md-6" >
    <
    div class = "ami-wrap" >
    <
    ul class = "aminitieslist dir pd0" >
    <
    li > East - West Vastu Compliant < span > < /span></li >
    <
    li > Low Density Apartments < span > < /span></li >

    <
    /ul> <
    /div> <
    /div> <
    div class = "col-md-6" >
    <
    div class = "ami-wrap" >
    <
    ul class = "aminitieslist dir pd0" >
    <
    li > Home Automation < span > < /span></li >
    <
    li > Dual Level Amenities < span > < /span></li >

    <
    /ul> <
    /div> <
    /div> <
    /div>


    <!-- <div class="col-md-6 col-xs-12" data-aos="fade-right" data-aos-delay="200" data-aos-duration="1000">

    <
    img src = "images/about.png"
class = "img-responsive overview-img " >

    <
    /div> --> <
    /div>






    <
    /div> <
    /section> <
    section id = "configuration" >
    <
    div class = "glob-sec-bg" >
    <
    div class = "overlay1" >
    <
    div class = "container" >
    <!-- <img class="head-icon wow fadeInUp" data-wow-duration="1s" data-wow-delay="1s"
    src = "images/head-icon-white.png" > -->
    <
    h2 class = "sec-head head-center white wow fadeInUp"
data - wow - duration = "1s"
data - wow - delay = "0.5s" >
    Configuration < /h2> <
    h3 class = "sub-head"
style = "color: #fff;" > < /h3> <
    div class = "head-line" > < /div>


    <
    table class = "table spe-table"
style = "text-align: center; margin: auto; width: 100%;color: #fff;border-color: #fff;"
border = "0"
cellspacing = "0"
cellpadding = "0" >
    <
    thead >
    <
    tr >

    <
    th class = "her" >
    Configuration <
    /th> <
    th class = "her" >
    Area(Sq.Ft) <
    /th>
    <!-- <th class="her" >Price
    <
    /th> --> <
    th class = "her" > Price <
    /th> <
    /tr> <
    /thead> <
    tbody style = "color: #1a3435;" >

    <
    tr style = "background-color: #fff;" >
    <
    td scope = "row"
class = "her1" > 1 BHK < /td> <
    td class = "her1" > 441 - 479 Sq.Ft. < /td>
    <!-- <td class="her1">1.68 CR*</td> -->
    <
    td class = "her1 cursor click_here" >
    <
    a href = "javascript:void(0)"
class = "price-click" >
    Click Here <
    /a> <
    /td> <
    /tr> <
    tr style = "background-color: #fff;" >
    <
    td scope = "row"
class = "her1" > 2 BHK < /td> <
    td class = "her1" > 614 - 652 Sq.Ft. < /td>
    <!-- <td class="her1">1.68 CR*</td> -->
    <
    td class = "her1 cursor click_here" >
    <
    a href = "javascript:void(0)"
class = "price-click" >
    Click Here <
    /a> <
    /td> <
    /tr>

    <
    /tbody> <
    /table>

    <
    /div> <
    /div> <
    /div> <
    /section> <
    section class = "glob-sec lighgrey"
id = "parkamenities" >
    <
    div class = "container" >
    <!-- <img class="head-icon wow fadeInUp" data-wow-duration="1s" data-wow-delay="1s" src="images/head-icon.png"> -->
    <
    h2 class = "sec-head head-center wow fadeInUp"
data - wow - duration = "1s"
data - wow - delay = "0.5s" >
    Amenities < /h2>
<!-- <h3 class="sub-head">Orchard at Atul Smartcode Gold class brings the best aspects of living, all together in one place. A
lifestyle enhanced by premium amenities meets a life made more comfortable with well - designed, lavish
interiors.So all your heart’ s desires can come true, all at once!
    <
    /h3> --> <
    div class = "head-line" > < /div>

    <!-- <div style="width: 100%;height: 50px;" class="col-md-12"></div> -->
    <!-- <h2 class="subhead">ROOFTOP AMENITIES </h2>

    <
    div class = "col-md-3 col-xs-12 wow fadeInUp"
data - wow - duration = "1s"
data - wow - delay = "0.5s" >
    <
    div class = "amiwrap border-effect" >
    <
    div class = "bo" >
    <
    i class = "flaticon-jogging" > < /i> <
    img src = "images/icon/1.png"
alt = "" >
    <
    p > Infifinity View Jacuzzi < /p> <
    /div> <
    /div> <
    /div> <
    div class = "col-md-3 col-xs-12 wow fadeInUp"
data - wow - duration = "1s"
data - wow - delay = "1s" >
    <
    div class = "amiwrap border-effect" >
    <
    div class = "bo" >
    <
    i class = "flaticon-amphitheatre" > < /i> <
    img src = "images/icon/2.png"
alt = "" >
    <
    p > Sky View Party < br > Lounge Area < /p> <
    /div> <
    /div> <
    /div> <
    div class = "col-md-3 col-xs-12 wow fadeInUp"
data - wow - duration = "1s"
data - wow - delay = "1.5s" >
    <
    div class = "amiwrap border-effect" >
    <
    div class = "bo" >
    <
    i class = "flaticon-garden" > < /i> <
    img src = "images/icon/3.png"
alt = "" >
    <
    p > Open Air Work Station < br > with Wi - Fi < /p> <
    /div> <
    /div> <
    /div> <
    div class = "col-md-3 col-xs-12 wow fadeInUp"
data - wow - duration = "1s"
data - wow - delay = "2s" >
    <
    div class = "amiwrap border-effect" >
    <
    div class = "bo" >
    <
    i class = "flaticon-pool" > < /i> <
    img src = "images/icon/4.png"
alt = "" >
    <
    p > Gazebo & Sit - Out Area < /p> <
    /div> <
    /div> <
    /div> <
    div class = "col-md-3 col-xs-12 wow fadeInUp"
data - wow - duration = "1s"
data - wow - delay = "2.5s" >
    <
    div class = "amiwrap border-effect" >
    <
    div class = "bo" >
    <
    i class = "flaticon-dumbbell" > < /i> <
    img src = "images/icon/5.png"
alt = "" >
    <
    p > Skywalk Acupressure < br > Pathway < /p> <
    /div> <
    /div> <
    /div> <
    div class = "col-md-3 col-xs-12 wow fadeInUp"
data - wow - duration = "1s"
data - wow - delay = "3.5s" >
    <
    div class = "amiwrap border-effect" >
    <
    div class = "bo" >
    <
    i class = "flaticon-kids" > < /i> <
    img src = "images/icon/6.png"
alt = "" >
    <
    p > Barbeque Deck Area < /p> <
    /div> <
    /div> <
    /div> <
    div class = "col-md-3 col-xs-12 wow fadeInUp"
data - wow - duration = "1s"
data - wow - delay = "3s" >
    <
    div class = "amiwrap border-effect" >
    <
    div class = "bo" >
    <
    i class = "flaticon-person-playing-billiard" > < /i> <
    img src = "images/icon/7.png"
alt = "" >
    <
    p > Observatory Deck < /p> <
    /div> <
    /div> <
    /div> <
    div class = "col-md-3 col-xs-12 wow fadeInUp"
data - wow - duration = "1s"
data - wow - delay = "3s" >
    <
    div class = "amiwrap border-effect" >
    <
    div class = "bo" >
    <
    i class = "flaticon-person-playing-billiard" > < /i> <
    img src = "images/icon/8.png"
alt = "" >
    <
    p > Open Air Mini theatre < /p> <
    /div> <
    /div> <
    /div>


    <
    h2 class = "col-md-12 subhead" > GROUND AMENITIES < /h2>

    <
    div class = "col-md-3 col-xs-12 wow fadeInUp"
data - wow - duration = "1s"
data - wow - delay = "4s" >
    <
    div class = "amiwrap border-effect" >
    <
    div class = "bo" >
    <
    i class = "flaticon-banquet-table" > < /i> <
    img src = "images/icon/9.png"
alt = "" >
    <
    p > Indoor Games(Pool Table < br > / Table Tennis ) <
        /p> <
        /div> <
        /div> <
        /div> <
        div class = "col-md-3 col-xs-12 wow fadeInUp"
        data - wow - duration = "1s"
        data - wow - delay = "4.5s" >
        <
        div class = "amiwrap border-effect" >
        <
        div class = "bo" >
        <
        i class = "flaticon-lift" > < /i> <
        img src = "images/icon/10.png"
        alt = "" >
        <
        p > Modern Fitness < br > Centre / Gymnasium < /p> <
        /div> <
        /div> <
        /div> <
        div class = "col-md-3 col-xs-12 wow fadeInUp"
        data - wow - duration = "1s"
        data - wow - delay = "5s" >
        <
        div class = "amiwrap border-effect" >
        <
        div class = "bo" >
        <
        i class = "flaticon-parking" > < /i> <
        img src = "images/icon/11.png"
        alt = "" >
        <
        p > Senior Citizen < br > Seat - Out Area < /p> <
        /div> <
        /div> <
        /div> <
        div class = "col-md-3 col-xs-12 wow fadeInUp"
        data - wow - duration = "1s"
        data - wow - delay = "5.5s" >
        <
        div class = "amiwrap border-effect" >
        <
        div class = "bo" >
        <
        i class = "flaticon-3d-building" > < /i> <
        img src = "images/icon/12.png"
        alt = "" >
        <
        p > Yoga Lawn & < br > Meditation Zone < /p> <
        /div> <
        /div> <
        /div> <
        div class = "col-md-3 col-xs-12 wow fadeInUp"
        data - wow - duration = "1s"
        data - wow - delay = "6s" >
        <
        div class = "amiwrap border-effect" >
        <
        div class = "bo" >
        <
        i class = "flaticon-security-camera" > < /i> <
        img src = "images/icon/13.png"
        alt = "" >
        <
        p > Medicinal Plant Garden < br > & Scented Flower Garden < /p> <
        /div> <
        /div> <
        /div> <
        div class = "col-md-3 col-xs-12 wow fadeInUp"
        data - wow - duration = "1s"
        data - wow - delay = "5s" >
        <
        div class = "amiwrap border-effect" >
        <
        div class = "bo" >
        <
        i class = "flaticon-parking" > < /i> <
        img src = "images/icon/14.png"
        alt = "" >
        <
        p > Children 's Play Area </p> <
        /div> <
        /div> <
        /div> <
        div class = "col-md-3 col-xs-12 wow fadeInUp"
        data - wow - duration = "1s"
        data - wow - delay = "5.5s" >
        <
        div class = "amiwrap border-effect" >
        <
        div class = "bo" >
        <
        i class = "flaticon-3d-building" > < /i> <
        img src = "images/icon/15.png"
        alt = "" >
        <
        p > Jogging Track < /p> <
        /div> <
        /div> <
        /div> <
        div class = "col-md-3 col-xs-12 wow fadeInUp"
        data - wow - duration = "1s"
        data - wow - delay = "6s" >
        <
        div class = "amiwrap border-effect" >
        <
        div class = "bo" >
        <
        i class = "flaticon-security-camera" > < /i> <
        img src = "images/icon/16.png"
        alt = "" >
        <
        p > Zen Water Fountain < /p> <
        /div> <
        /div> <
        /div> -->

        <
        div class = "tab-rwap" >
        <
        ul class = "nav nav-tabs mytab"
        role = "tablist" >


        <!-- <li role="presentation" class="active">
        <
        a href = "#general"
        aria - controls = "profile"
        role = "tab"
        data - toggle = "tab"
        aria - expanded = "true" > Exterior <
        /a> <
        /li> --> <
        li role = "presentation"
        class = "active" >
        <
        a href = "#roof"
        aria - controls = "settings"
        role = "tab"
        data - toggle = "tab"
        aria - expanded = "false" > ROOFTOP AMENITIES <
        /a> <
        /li> <
        li role = "presentation" >
        <
        a href = "#gro"
        aria - controls = "settings"
        role = "tab"
        data - toggle = "tab"
        aria - expanded = "false" > GROUND AMENITIES <
        /a> <
        /li>


        <
        /ul> <
        div class = "tab-content"
        style = "visibility: visible; animation-name: fadeInDown;" >



        <
        div role = "tabpanel"
        class = "tab-pane fade   active in"
        id = "roof" >
        <
        div class = "tab-contenwrap" >

        <
        div class = "col-md-4 pd0" >
        <
        div class = "amenities-gallery mg-mb" >
        <
        img src = "images/gallery/roof/1.jpg" >
        <
        a data - fancybox = "general"
        href = "images/gallery/roof/1.jpg"
        class = "l-box" >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        p class = "capt-text" > Infinity View Jacuzzi < /p> <
        /div> <
        /div>

        <
        div class = "col-md-4 pd0" >
        <
        div class = "amenities-gallery mg-mb" >
        <
        img src = "images/gallery/roof/2.jpg" >
        <
        a data - fancybox = "general"
        href = "images/gallery/roof/2.jpg"
        class = "l-box" >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        p class = "capt-text" > Gazebo & Seat - Out Area < /p> <
        /div> <
        /div>

        <
        div class = "col-md-4 pd0" >
        <
        div class = "amenities-gallery mg-mb" >
        <
        img src = "images/gallery/roof/3.jpg" >
        <
        a data - fancybox = "general"
        href = "images/gallery/roof/3.jpg"
        class = "l-box" >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        p class = "capt-text" > Observatory Deck < /p> <
        /div> <
        /div>


        <
        div class = "col-md-4 col-md-offset-2 pd0" >
        <
        div class = "amenities-gallery mg-mb" >
        <
        img src = "images/gallery/roof/4.jpg" >
        <
        a data - fancybox = "general"
        href = "images/gallery/roof/4.jpg"
        class = "l-box" >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        p class = "capt-text" > Open Air Mini Theater < /p> <
        /div> <
        /div>

        <
        div class = "col-md-4 pd0" >
        <
        div class = "amenities-gallery mg-mb" >
        <
        img src = "images/gallery/roof/5.jpg" >
        <
        a data - fancybox = "general"
        href = "images/gallery/roof/5.jpg"
        class = "l-box" >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        p class = "capt-text" > Sky View Party Lounge Area < /p> <
        /div> <
        /div>


        <
        /div> <
        /div>

        <
        div role = "tabpanel"
        class = "tab-pane fade  in"
        id = "gro" >
        <
        div class = "tab-contenwrap" >

        <
        div class = " col-md-4 pd0" >
        <
        div class = "amenities-gallery mg-mb" >
        <
        img src = "images/gallery/ground/1.jpg" >
        <
        a data - fancybox = "general"
        href = "images/gallery/ground/1.jpg"
        class = "l-box" >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        p class = "capt-text" > Modern Fitness Centre < /p> <
        /div> <
        /div>


        <
        div class = " col-md-4 pd0" >
        <
        div class = "amenities-gallery mg-mb" >
        <
        img src = "images/gallery/ground/2.jpg" >
        <
        a data - fancybox = "general"
        href = "images/gallery/ground/2.jpg"
        class = "l-box" >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        p class = "capt-text" > Table Tennis < /p>

        <
        /div> <
        /div>


        <
        div class = " col-md-4 pd0" >
        <
        div class = "amenities-gallery mg-mb" >
        <
        img src = "images/gallery/ground/3.jpg" >
        <
        a data - fancybox = "general"
        href = "images/gallery/ground/3.jpg"
        class = "l-box" >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        p class = "capt-text" > Senior Citizen Seat - Out Area < /p>

        <
        /div> <
        /div>



        <
        div class = " col-md-4 pd0" >
        <
        div class = "amenities-gallery mg-mb" >
        <
        img src = "images/gallery/ground/4.jpg" >
        <
        a data - fancybox = "general"
        href = "images/gallery/ground/4.jpg"
        class = "l-box" >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        p class = "capt-text" > Jogging Track < /p>

        <
        /div> <
        /div>

        <
        div class = " col-md-4 pd0" >
        <
        div class = "amenities-gallery mg-mb" >
        <
        img src = "images/gallery/ground/5.jpg" >
        <
        a data - fancybox = "general"
        href = "images/gallery/ground/5.jpg"
        class = "l-box" >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        p class = "capt-text" > Kid 's Play Area</p>

        <
        /div> <
        /div>


        <
        /div> <
        /div> <
        /div> <
        /div> <
        /div> <
        /section>





        <
        section class = ""
        id = "gallery" >
        <
        div class = "overlay1" >
        <
        div class = "container" >
        <!-- <img class="head-icon wow fadeInUp" data-wow-duration="1s" data-wow-delay="1s" src="images/head-icon.png"> -->
        <
        h2 class = "sec-head head-center wow fadeInUp white"
        data - wow - duration = "1s"
        data - wow - delay = "0.5s" > Gallery <
        /h2>
        <!--<h3 class="sub-head">View Your Dream Homes</h3>-->
        <
        div class = "head-line" > < /div>

        <
        div style = "width: 100%;height: 20px;" > < /div>

        <
        div class = "tab-rwap" >
        <
        ul class = "nav nav-tabs mytab"
        role = "tablist" >


        <
        li role = "presentation"
        class = "active" >
        <
        a href = "#inte"
        aria - controls = "profile"
        role = "tab"
        data - toggle = "tab"
        aria - expanded = "true" > Exterior <
        /a> <
        /li> <
        li role = "presentation"
        class = "" >
        <
        a href = "#interior"
        aria - controls = "settings"
        role = "tab"
        data - toggle = "tab"
        aria - expanded = "false" > Interior <
        /a> <
        /li> <
        li role = "presentation" >
        <
        a href = "#floor"
        aria - controls = "settings"
        role = "tab"
        data - toggle = "tab"
        aria - expanded = "false" > Floor Plans <
        /a> <
        /li>


        <
        /ul> <
        div class = "tab-content"
        style = "visibility: visible; animation-name: fadeInDown;" >



        <
        div role = "tabpanel"
        class = "tab-pane fade  active in"
        id = "inte" >
        <
        div class = "tab-contenwrap" >

        <
        div class = "col-md-4 pd0" >
        <
        div class = "amenities-gallery mg-mb" >
        <
        img src = "images/gallery/interior/1.jpg" >
        <
        a data - fancybox = "general"
        href = "images/gallery/interior/1.jpg"
        class = "l-box" >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        p class = "capt-text" > Artist 's Impression</p> <
        /div> <
        /div>

        <
        div class = "col-md-4 pd0" >
        <
        div class = "amenities-gallery mg-mb" >
        <
        img src = "images/gallery/interior/2.jpg" >
        <
        a data - fancybox = "general"
        href = "images/gallery/interior/2.jpg"
        class = "l-box" >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        p class = "capt-text" > Artist 's Impression</p> <
        /div> <
        /div>

        <
        div class = "col-md-4 pd0" >
        <
        div class = "amenities-gallery mg-mb" >
        <
        img src = "images/gallery/interior/4.jpg" >
        <
        a data - fancybox = "general"
        href = "images/gallery/interior/4.jpg"
        class = "l-box" >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        p class = "capt-text" > Artist 's Impression</p> <
        /div> <
        /div>

        <
        /div> <
        /div>

        <
        div role = "tabpanel"
        class = "tab-pane fade  in"
        id = "interior" >
        <
        div class = "tab-contenwrap" >


        <
        div class = " col-md-4 pd0" >
        <
        div class = "amenities-gallery mg-mb" >
        <
        img src = "images/gallery/interior/3.jpg" >
        <
        a data - fancybox = "general"
        href = "images/gallery/interior/3.jpg"
        class = "l-box" >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        p class = "capt-text" > Artist 's Impression</p> <
        /div> <
        /div> <
        div class = " col-md-4 pd0" >
        <
        div class = "amenities-gallery mg-mb" >
        <
        img src = "images/gallery/interior/5.jpg" >
        <
        a data - fancybox = "general"
        href = "images/gallery/interior/5.jpg"
        class = "l-box" >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        p class = "capt-text" > Artist 's Impression</p> <
        /div> <
        /div> <
        div class = " col-md-4 pd0" >
        <
        div class = "amenities-gallery mg-mb" >
        <
        img src = "images/gallery/interior/6.jpg" >
        <
        a data - fancybox = "general"
        href = "images/gallery/interior/6.jpg"
        class = "l-box" >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        p class = "capt-text" > Artist 's Impression</p> <
        /div> <
        /div>

        <!--  <div class="  col-md-4 pd0">
        <
        div class = "amenities-gallery mg-mb" >
        <
        img src = "images/gallery/ame/3.jpg" >
        <
        a data - fancybox = "general"
        href = "images/gallery/ame/3.jpg"
        class = "l-box" >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        /div> <
        /div> -->

        <
        /div> <
        /div>

        <
        div role = "tabpanel"
        class = "tab-pane fade  in"
        id = "floor" >
        <
        div class = "tab-contenwrap" >


        <
        div class = " col-md-4 pd0" >
        <
        div class = "amenities-gallery mg-mb floor blur" >
        <
        img src = "images/gallery/floor/1.jpg" >
        <
        a >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a>
        <!-- <p class="capt-text">Artist's Impression</p> -->
        <
        /div> <
        /div>

        <
        div class = "col-md-4 pd0" >
        <
        div class = "amenities-gallery mg-mb floor blur" >
        <
        img src = "images/gallery/floor/2.jpg" >
        <
        a >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        /div> <
        /div> <
        div class = " col-md-4 pd0" >
        <
        div class = "amenities-gallery mg-mb floor blur" >
        <
        img src = "images/gallery/floor/3.jpg" >
        <
        a >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a>
        <!-- <p class="capt-text">Artist's Impression</p> -->
        <
        /div> <
        /div>

        <
        div class = "col-md-4 pd0" >
        <
        div class = "amenities-gallery mg-mb floor blur" >
        <
        img src = "images/gallery/floor/4.jpg" >
        <
        a >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        /div> <
        /div> <
        div class = " col-md-4 pd0" >
        <
        div class = "amenities-gallery mg-mb floor blur" >
        <
        img src = "images/gallery/floor/5.jpg" >
        <
        a >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a>
        <!-- <p class="capt-text">Artist's Impression</p> -->
        <
        /div> <
        /div>

        <
        div class = "col-md-4 pd0" >
        <
        div class = "amenities-gallery mg-mb floor blur" >
        <
        img src = "images/gallery/floor/6.jpg" >
        <
        a >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        /div> <
        /div> <
        div class = "col-md-4 pd0" >
        <
        div class = "amenities-gallery mg-mb floor blur" >
        <
        img src = "images/gallery/floor/7.jpg" >
        <
        a >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        /div> <
        /div> <
        div class = "col-md-4 pd0" >
        <
        div class = "amenities-gallery mg-mb floor blur" >
        <
        img src = "images/gallery/floor/8.jpg" >
        <
        a >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        /div> <
        /div> <
        div class = "col-md-4 pd0" >
        <
        div class = "amenities-gallery mg-mb floor blur" >
        <
        img src = "images/gallery/floor/9.jpg" >
        <
        a >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        /div> <
        /div>

        <
        /div> <
        /div> <
        /div> <
        /div>

        <
        /section>


        <!-- <section class="glob-sec" id="plan">
        <
        div class = "container" >
        <
        h2 class = "sec-head head-center wow fadeInUp"
        data - wow - duration = "1s"
        data - wow - delay = "0.5s" > Floor Plans < /h2> <
        div class = "head-line" > < /div>

        <
        div style = "width: 100%;height: 20px;" > < /div>

        <
        div class = "tab-rwap" >
        <
        ul class = "nav nav-tabs mytab"
        role = "tablist" >


        <
        /ul> <
        div class = "tab-content"
        style = "visibility: visible; animation-name: fadeInDown;" >

        <
        div class = "owl-carousel owl-theme" >

        <
        div class = "item" >
        <
        div class = "amenities-gallery mg-mb floor" >
        <
        img src = "images/gallery/floorplan/1.png"
        style = "filter: blur(1px);-webkit-filter: blur(1px);" >

        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        /div> <
        /div> <
        div class = "item" >
        <
        div class = "amenities-gallery mg-mb floor" >
        <
        img src = "images/gallery/floorplan/3.png"
        style = "filter: blur(1px);-webkit-filter: blur(1px);" >

        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        /div> <
        /div>

        <
        div class = "item" >
        <
        div class = "amenities-gallery mg-mb floor" >
        <
        img src = "images/gallery/floorplan/2.png"
        style = "filter: blur(1px);-webkit-filter: blur(1px);" >

        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        /div> <
        /div>

        <
        div class = "item" >
        <
        div class = "amenities-gallery mg-mb floor" >
        <
        img src = "images/gallery/floorplan/4.png"
        style = "filter: blur(1px);-webkit-filter: blur(1px);" >

        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        /div> <
        /div> <
        div class = "item" >
        <
        div class = "amenities-gallery mg-mb floor" >
        <
        img src = "images/gallery/floorplan/5.png"
        style = "filter: blur(1px);-webkit-filter: blur(1px);" >

        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        /div> <
        /div>

        <
        div class = "item" >
        <
        div class = "amenities-gallery mg-mb floor" >
        <
        img src = "images/gallery/floorplan/6.png"
        style = "filter: blur(1px);-webkit-filter: blur(1px);" >

        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        /div> <
        /div>


        <
        div class = "item" >
        <
        div class = "amenities-gallery mg-mb floor" >
        <
        img src = "images/gallery/floorplan/7.png"
        style = "filter: blur(1px);-webkit-filter: blur(1px);" >

        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        /div> <
        /div> <
        /div> <
        /div> <
        /div> <
        /div> <
        /section> -->

        <
        section class = "glob-sec-bg grey-bg"
        id = "location" >
        <
        div class = "" >
        <
        div class = "container" >
        <!-- <img class="head-icon wow fadeInUp" data-wow-duration="1s" data-wow-delay="1s"
        src = "images/head-icon-white.png" > -->
        <
        h2 class = "sec-head head-center  wow fadeInUp"
        data - wow - duration = "1s"
        data - wow - delay = "0.5s" >
        Connectivity < /h2> <
        h3 class = "sub-head" > < /h3>
        <!-- <h3 class="sub-head">THEULTIMATE COMBINATION OF CONNECTIVITY AND COMFORT</h3> -->

        <
        div class = "head-line" > < /div>


        <
        div class = "col-md-6" >
        <
        div class = "panel-group cust-accordion"
        id = "accordion"
        role = "tablist"
        aria - multiselectable = "true" >

        <
        div class = "panel panel-default" >
        <
        div class = "panel-heading"
        role = "tab"
        id = "heading2" >
        <
        h4 class = "panel-title" >
        <
        a class = "collapsed"
        role = "button"
        data - toggle = "collapse"
        data - parent = "#accordion4"
        href = "#collapse4"
        aria - expanded = "true"
        aria - controls = "collapse4" >
        RAILWAY STATION <
        /a> <
        /h4> <
        /div> <
        div id = "collapse4"
        class = "panel-collapse collapse in"
        role = "tabpanel"
        aria - labelledby = "heading2"
        aria - expanded = "true" >
        <
        div class = "panel-body" >
        <
        ul class = "specification" >
        <
        li > Kalyan Station - 10 mins < /li> <
        li > Vittalwadi Station - 15 mins < /li> <
        li > Dombivali Station - 20 mins < /li> <
        li > Thakurli Station - 15 mins < /li> <
        li > Ulhasnagar Station - 20 mins < /li>

        <
        /ul> <
        /div> <
        /div> <
        /div>

        <
        div class = "panel panel-default" >
        <
        div class = "panel-heading"
        role = "tab"
        id = "headingTwo" >
        <
        h4 class = "panel-title" >
        <
        a class = "collapsed"
        role = "button"
        data - toggle = "collapse"
        data - parent = "#accordion"
        href = "#collapseTwo"
        aria - expanded = "false"
        aria - controls = "collapseTwo" >
        HOSPITAL <
        /a> <
        /h4> <
        /div> <
        div id = "collapseTwo"
        class = "panel-collapse collapse"
        role = "tabpanel"
        aria - labelledby = "headingTwo"
        aria - expanded = "false"
        style = "height: 0px;" >
        <
        div class = "panel-body" >
        <
        ul class = "specification" >
        <
        li > Fortis Hospital - 10 mins < /li> <
        li > Meera Hospital - 15 mins < /li> <
        li > AM - PM 24 / 7 Hospital - 10 mins < /li> <
        /ul> <
        /div> <
        /div> <
        /div> <
        div class = "panel panel-default" >
        <
        div class = "panel-heading"
        role = "tab"
        id = "headingOne" >
        <
        h4 class = "panel-title" >
        <
        a role = "button"
        data - toggle = "collapse"
        data - parent = "#accordion"
        href = "#collapseOne"
        aria - expanded = "false"
        aria - controls = "collapseOne"
        class = "collapsed" >
        BANKS <
        /a> <
        /h4> <
        /div> <
        div id = "collapseOne"
        class = "panel-collapse collapse"
        role = "tabpanel"
        aria - labelledby = "headingOne"
        aria - expanded = "false"
        style = "height: 0px;" >
        <
        div class = "panel-body" >
        <
        ul class = "specification" >
        <
        li > Bank Of Baroda - 7 mins < /li> <
        li > Axis Bank - 7 mins < /li> <
        li > ICICI Bank - 5 mins < /li> <
        /ul> <
        /div> <
        /div> <
        /div>




        <
        div class = "panel panel-default" >
        <
        div class = "panel-heading"
        role = "tab"
        id = "heading2" >
        <
        h4 class = "panel-title" >
        <
        a class = "collapsed"
        role = "button"
        data - toggle = "collapse"
        data - parent = "#accordion2"
        href = "#collapse2"
        aria - expanded = "false"
        aria - controls = "collapse2" >
        SHOPS <
        /a> <
        /h4> <
        /div> <
        div id = "collapse2"
        class = "panel-collapse collapse"
        role = "tabpanel"
        aria - labelledby = "heading2"
        aria - expanded = "false" >
        <
        div class = "panel-body" >
        <
        ul class = "specification" >
        <
        li > D’ mart - 10 mins < /li> <
        li > Metro Mall - 5 mins < /li> <
        li > Big Bazar - 5 mins < /li> <
        li > Palava Xperia Mall - 20 mins < /li> <
        /ul> <
        /div> <
        /div> <
        /div>


        <
        div class = "panel panel-default" >
        <
        div class = "panel-heading"
        role = "tab"
        id = "heading1" >
        <
        h4 class = "panel-title" >
        <
        a role = "button"
        data - toggle = "collapse"
        data - parent = "#accordion2"
        href = "#collapse1"
        aria - expanded = "false"
        aria - controls = "collapse1"
        class = "collapse1" >
        SCHOOL <
        /a> <
        /h4> <
        /div> <
        div id = "collapse1"
        class = "panel-collapse collapse"
        role = "tabpanel"
        aria - labelledby = "heading1"
        aria - expanded = "false"
        style = "height: 0px;" >
        <
        div class = "panel-body" >
        <
        ul class = "specification" >
        <
        li > Omkar School - 9 mins < /li> <
        li > Arya Gurukul School - 7 mins < /li> <
        li > Model College of Science & Commerce– 10 mins < /li> <
        li > St.Paul’ s College - 15 mins < /li> <
        li > B.K Birla College - 15 mins < /li> <
        li > Saket College of Arts & Science - 12 mins < /li> <
        /ul> <
        /div> <
        /div> <
        /div>
        <!-- <div class="panel panel-default">
        <
        div class = "panel-heading"
        role = "tab"
        id = "heading2" >
        <
        h4 class = "panel-title" >
        <
        a class = "collapsed"
        role = "button"
        data - toggle = "collapse"
        data - parent = "#accordion5"
        href = "#collapse5"
        aria - expanded = "false"
        aria - controls = "collapse5" >
        GREEN ZONE <
        /a> <
        /h4> <
        /div> <
        div id = "collapse5"
        class = "panel-collapse collapse"
        role = "tabpanel"
        aria - labelledby = "heading2"
        aria - expanded = "false" >
        <
        div class = "panel-body" >
        <
        ul class = "specification" >
        <
        li > Thakur Cricket Ground - 200 m < /li> <
        li > T.P.Jogging Park - 400 m < /li> <
        li > Dream Park - 600 m < /li> <
        li > Sanjay Gandhi National Park - 2.0 km <
        /li>


        <
        /ul> <
        /div> <
        /div> <
        /div> -->

        <
        /div>

        <
        /div>

        <
        div class = "col-md-6" >
        <
        div class = "amenities-gallery-1 mg-mb" >
        <
        img src = "images/map.jpg"
        class = "loc" >
        <
        a data - fancybox = "general"
        href = "images/map.jpg"
        class = "l-box" >
        <
        div class = "ami-overlay" >
        <
        /div> <
        /a> <
        /div>

        <
        /div>
        <!-- <div class="col-md-12">
        <
        a href = "javascript:void(0);"
        class = "maplink" > View Map < /a> <
        /div> --> <
        /div> <
        /div> <
        /section>

        <!-- <section class="glob-sec" style="text-align: center;" id="aboutus">
        <
        div class = "container" >
        <
        img class = "head-icon wow fadeInUp"
        data - wow - duration = "1s"
        data - wow - delay = "1s"
        src = "images/head-icon.png" >
        <
        h2 class = "sec-head head-center wow fadeInUp"
        data - wow - duration = "1s"
        data - wow - delay = "0.5s" > About Us < /h2> <
        h3 class = "sub-head" > Best Of Both Worlds < /h3> <
        div class = "head-line" > < /div> <
        div class = "" >


        <
        div class = "col-md-12 col-xs-12 wow fadeInUp"
        data - wow - duration = "1s"
        data - wow - delay = "1s" >
        <
        div class = "amiwrap about border-effect" >

        <
        div class = "row" >
        <
        div class = "col-md-12" >

        <
        div class = "col-md-12" >
        <
        img src = "images/logo2.png"
        width = "200" >

        <
        p class = "text-center" >
        Smartcode Gold class have made their mark in Mumbai as one of the most reliable real estate companies in the city.What makes us different from our competitors is the fact that we add life to your lifestyle by giving you the best possible choices that not only suit your budget but also give you the satisfaction of
        investing your hard - earned money in the right place; and the right space.The pioneers of Smartcode Gold class are - founder Mr.Nathalal Delwadia, Managing director– Mr.Atul Patel and Director– Mr.Aakash Patel.Our milestones include immaculate work in commercial, residential, industrial and hospitality projects.


        <
        /p>

        <
        /div> <
        /div> <
        /div> <
        /div> <
        /div>



        <
        /div> <
        /section> -->




        <
        section class = " glob-sec-bg light-grey" >
        <
        div class = "container-fluid" >
        <
        div class = "col-md-6 pd0" >
        <
        iframe src = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3767.440813037621!2d73.1309517!3d19.2196111!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7958f3281c837%3A0xa880a386e30eaa81!2sGaondevi%20Crown!5e0!3m2!1sen!2sin!4v1680610898095!5m2!1sen!2sin"
        width = "100%"
        height = "550"
        style = "border:0;"
        allowfullscreen = ""
        loading = "lazy"
        referrerpolicy = "no-referrer-when-downgrade" > < /iframe> <
        /div> <
        div class = "col-md-6 pd0"
        id = "contactus" >
        <
        div class = "overlay" >
        <
        div class = "container" >

        <
        h2 class = "sec-head head-center white wow fadeInUp"
        data - wow - duration = "1s"
        data - wow - delay = "0.5s" >
        Contact Us < /h2> <
        div class = "head-line" > < /div> <
        div class = "col-md-12" >
        <
        div class = "form-wrap" >
        <
        h1 > Please enter the details below to get in touch with us! < /h1> <
        form id = "contact-form"
        action = "thank-you.php"
        name = "contact-form"
        method = "POST"
        onsubmit = "return save_landing_pageinfo('contact-form');"
        novalidate = "novalidate" >

        <
        div class = "form-group col-md-12" >
        <
        div class = "input-group" >
        <
        div class = "input-group-addon" >
        <
        i class = "fa fa-user form-ico"
        aria - hidden = "true" > < /i> <
        /div> <
        input type = "text"
        class = "form-control"
        name = "fname"
        placeholder = " Name" >
        <
        /div> <
        label
        for = "fname"
        generated = "true"
        class = "error" > < /label> <
        /div>


        <
        div class = "form-group col-md-12" >
        <
        div class = "input-group" >
        <
        div class = "input-group-addon" >
        <
        i class = "fa fa-mobile form-ico"
        aria - hidden = "true" > < /i> <
        /div> <
        input type = "number"
        class = "form-control"
        name = "mobile"
        placeholder = "Mobile" >
        <
        /div> <
        label
        for = "mobile"
        generated = "true"
        class = "error" > < /label> <
        /div> <
        div class = "form-group col-md-12" >
        <
        div class = "input-group" >
        <
        div class = "input-group-addon" >
        <
        i class = "fa fa-envelope"
        aria - hidden = "true" > < /i> <
        /div> <
        input type = "email"
        class = "form-control"
        name = "email"
        placeholder = "Email" >
        <
        input type = "hidden"
        name = "source"
        value = "Enquiry Form" >
        <
        /div> <
        label
        for = "email"
        generated = "true"
        class = "error" > < /label> <
        /div>


        <
        button type = "submit"
        class = "btn btn-default form-btn hvr-sweep-to-right" > Submit <
        /button> <
        /form> <
        p class = "foo-txt" > For More Information Please Call < /p> <
        p class = "footer-call" > < i class = "fa fa-phone"
        style = "transform: rotate(93deg);" > < /i> <
        a href = "tel:8779516087" > 8779516087 < /a> <
        /p> <
        /div> <
        /div> <
        /div> <
        /div> <
        /div> <
        /div> <
        /div> <
        /section>

        <
        section class = "footer-sec"
        id = "footer" >
        <
        div class = "container" >
        <
        div class = "foote-wrap" >
        <
        img src = "images/logo3.png" >
        <!--<img class="head-icon" src="images/head-icon.png">-->

        <
        div class = "contacwrap" >


        <
        ul class = "address" >
        <!-- <li><i class="fas fa-phone"></i> 022 6144 6641</li> -->
        <
        li > < i class = "fas fa-building" > < /i> Gold Class Sales Lounge 48/
        3 at Tisgaon,
        Near Haji Malang Road Kalyan, Thane - 421 306(Maharashtra) < /li> <
        /ul>

        <!-- <p style="margin-top: 0;">
        By submitting your details you agree to the our <
        a class = "disc-btn"
        href = "terms-and-conditions.php" > Terms & Conditions < /a> <
        /p> -->

        <
        div class = "address-line" > < /div> <
        ul class = "reralist" >

        <
        li > < img src = "images/maha-rera.png"
        style = "display: inline-block;width: 28px;position:  absolute;margin-left: -24px;margin-top: -5px;" > & nbsp; MahaRERA Registration No: < b > P51700031502 < /b></li >
        <
        li >
        For more details visit the website: < a href = "https://maharera.mahaonline.gov.in"
        target = "_blank" >
        https: //maharera.mahaonline.gov.in</a>
        <
        /li> <
        /ul>

        <
        div style = "width: 100%;height: 20px;" > < /div>

        <
        p class = "copy-right" > ©Smartcode Gold class All Rights Reserved 2023. < /p>

        <
        /div>

        <
        /div> <
        /div> <
        /section> <
        section class = "rera-sec" >
        <
        div class = "container cust-container" >
        <
        div class = "patch" >
        <!-- <div class="col-md-3">
        <
        img src = "images/patch.jpg"
        class = "img-responsive"
        alt = "" >
        <
        /div> --> <
        div class = "col-md-8" >
        <!-- <h3>Disclaimer</h3> -->
        <
        p >
        <
        b > Disclaimer < /b>
        The amenities, specifications, facilities, surrounding infrastructure, stock images and features shown and / or mentioned and the image renders used herein are purely indicative and promotional and may differ from the actuals.This is only an invitation to offer and does not constitute an offer.The purpose of this advertisement is to indicate to the customers the extent of the amenities and facilities that may come up in the project as per the present approved layout.Any prospective sale shall strictly be governed by the terms and conditions of
        the agreement
        for sale to be entered into between the parties. <
        /p>

        <
        /div>

        <
        /div> <
        /div> <
        /section>


        <
        div class = "col-lg-12 col-sm-12 col-xs-12 fixed-footer-cust hidden-md hidden-lg hidden-sm" >
        <
        div class = "container" >
        <
        div class = "col-lg-6 col-sm-6 col-xs-6 div-line pd0" >
        <
        a href = "tel:8779516087"
        class = "fix-link clickme" > < i class = "fa fa-phone f-icon"
        aria - hidden = "true" > < /i>
        GET CALL < /a> <
        /div> <
        div class = "col-lg-6 col-sm-6 col-xs-6 pd0 " >
        <
        button class = "btn  fix-link i-am colcall text-center" > < i class = "fa fa-envelope" > < /i> ENQUIRE
        NOW <
        /button> <
        /div> <
        /div> <
        /div>


        <
        div id = "pageloader" >
        <
        img src = "images/loading.gif"
        alt = "processing..." / >
        <
        /div>

        <!-- ================ main popup ==================== -->

        <
        div class = "modal fade in"
        tabindex = "-1"
        role = "dialog"
        id = "main-pop"
        data - backdrop = "static"
        data - keyboard = "false" >
        <
        div class = "modal-dialog"
        role = "document" >
        <
        div class = "modal-content" >
        <
        div class = "modal-header" >
        <
        button type = "button"
        class = "close"
        data - dismiss = "modal"
        aria - label = "Close" > < span aria - hidden = "true" > × < /span></button >

        <
        h4 class = "modal-title" > Enquire Now < /h4> <
        /div> <
        div class = "modal-body" >
        <
        p > Please Enter Your Details To Know More About Atul Smartcode Gold class < /p> <
        form id = "main-popup"
        action = "thank-you.php"
        name = "main-popup"
        method = "POST"
        novalidate = "novalidate"
        onsubmit = "return save_landing_pageinfo('main-popup');" >
        <
        div class = "form-group col-md-12" >
        <
        div class = "input-group" >
        <
        div class = "input-group-addon" >
        <
        i class = "fa fa-user form-ico"
        aria - hidden = "true" > < /i> <
        /div> <
        input type = "text"
        class = "form-control"
        name = "fname"
        placeholder = "Name" >
        <
        input type = "hidden"
        name = "source"
        value = "Main PopUp" >
        <
        /div> <
        label
        for = "fname"
        generated = "true"
        class = "error" > < /label> <
        /div> <
        div class = "form-group col-md-12" >
        <
        div class = "input-group" >
        <
        div class = "input-group-addon" >
        <
        i class = "fa fa-mobile form-ico"
        aria - hidden = "true" > < /i> <
        /div> <
        input type = "number"
        class = "form-control"
        name = "mobile"
        placeholder = "Mobile" >
        <
        /div> <
        label
        for = "mobile"
        generated = "true"
        class = "error" > < /label> <
        /div> <
        div class = "form-group col-md-12" >
        <
        div class = "input-group" >
        <
        div class = "input-group-addon" >
        <
        i class = "fa fa-envelope"
        aria - hidden = "true" > < /i> <
        /div> <
        input type = "email"
        class = "form-control"
        name = "email"
        placeholder = "Email" >
        <
        /div> <
        label
        for = "email"
        generated = "true"
        class = "error" > < /label> <
        /div>

        <
        button type = "submit"
        class = "btn btn-default price-btn hvr-sweep-to-right" > SUBMIT < /button> <
        /form>


        <
        /div> <
        /div><!-- /.modal - content -->
        <
        /div><!-- /.modal - dialog-- >
        <
        /div>

        <!-- ============================================= -->


        <!-- ================ price popup ==================== -->


        <
        div class = "modal fade in"
        tabindex = "-1"
        role = "dialog"
        id = "price-model"
        data - backdrop = "static"
        data - keyboard = "false" >
        <
        div class = "modal-dialog"
        role = "document" >
        <
        div class = "modal-content" >
        <
        div class = "modal-header" >
        <
        button type = "button"
        class = "close"
        data - dismiss = "modal"
        aria - label = "Close" > < span aria - hidden = "true" > × < /span></button >

        <
        h4 class = "modal-title" > Pricing Information < /h4> <
        /div> <
        div class = "modal-body" >
        <
        p > Please Enter Your Details To Get Pricing Information < /p> <
        form id = "price-popup"
        action = "thank-you.php"
        name = "price-popup"
        method = "POST"
        novalidate = "novalidate"
        onsubmit = "return save_landing_pageinfo('price-popup');" >
        <
        div class = "form-group col-md-12" >
        <
        div class = "input-group" >
        <
        div class = "input-group-addon" >
        <
        i class = "fa fa-user form-ico"
        aria - hidden = "true" > < /i> <
        /div> <
        input type = "text"
        class = "form-control"
        name = "fname"
        placeholder = "Name" >
        <
        input type = "hidden"
        name = "source"
        value = "Price PopUp" >
        <
        /div> <
        label
        for = "fname"
        generated = "true"
        class = "error" > < /label> <
        /div> <
        div class = "form-group col-md-12" >
        <
        div class = "input-group" >
        <
        div class = "input-group-addon" >
        <
        i class = "fa fa-mobile form-ico"
        aria - hidden = "true" > < /i> <
        /div> <
        input type = "number"
        class = "form-control"
        name = "mobile"
        placeholder = "Mobile" >
        <
        /div> <
        label
        for = "mobile"
        generated = "true"
        class = "error" > < /label> <
        /div> <
        div class = "form-group col-md-12" >
        <
        div class = "input-group" >
        <
        div class = "input-group-addon" >
        <
        i class = "fa fa-envelope"
        aria - hidden = "true" > < /i> <
        /div> <
        input type = "email"
        class = "form-control"
        name = "email"
        placeholder = "Email" >
        <
        /div> <
        label
        for = "email"
        generated = "true"
        class = "error" > < /label> <
        /div>

        <
        button type = "submit"
        class = "btn btn-default price-btn hvr-sweep-to-right" > SUBMIT < /button> <
        /form> <
        /div> <
        /div><!-- /.modal - content -->
        <
        /div><!-- /.modal - dialog-- >
        <
        /div>

        <!-- ============================================= -->

        <
        button class = "btn btn-danger interested hidden-xs" > Enquire Now < /button> <
        button class = "btn btn-danger download1 btn-download hidden-xs" > Download Brochure < /button>
        <!-- ================ i am ==================== -->
        <
        div class = "modal fade in"
        tabindex = "-1"
        role = "dialog"
        id = "interested"
        data - backdrop = "static"
        data - keyboard = "false" >
        <
        div class = "modal-dialog"
        role = "document" >
        <
        div class = "modal-content" >
        <
        div class = "modal-header" >
        <
        button type = "button"
        class = "close"
        data - dismiss = "modal"
        aria - label = "Close" >
        <
        span aria - hidden = "true" > × < /span> <
        /button> <
        h4 class = "modal-title" > Enquire Now < /h4> <
        /div> <
        div class = "modal-body" >
        <
        p > Please Enter Your Details To Know More About Smartcode Gold class < /p> <
        form id = "float-form"
        action = "thank-you.php"
        name = "price-popup"
        method = "POST"
        novalidate = "novalidate"
        onsubmit = "return save_landing_pageinfo('float-form');" >
        <
        div class = "form-group col-md-12" >
        <
        div class = "input-group" >
        <
        div class = "input-group-addon" >
        <
        i class = "fa fa-user form-ico"
        aria - hidden = "true" > < /i> <
        /div> <
        input type = "text"
        class = "form-control"
        name = "fname"
        placeholder = "Name" >
        <
        input type = "hidden"
        name = "source"
        value = "Im Interested" >
        <
        /div> <
        label
        for = "fname"
        generated = "true"
        class = "error" > < /label> <
        /div> <
        div class = "form-group col-md-12" >
        <
        div class = "input-group" >
        <
        div class = "input-group-addon" >
        <
        i class = "fa fa-mobile form-ico"
        aria - hidden = "true" > < /i> <
        /div> <
        input type = "number"
        class = "form-control"
        name = "mobile"
        placeholder = "Mobile" >
        <
        /div> <
        label
        for = "mobile"
        generated = "true"
        class = "error" > < /label> <
        /div>

        <
        div class = "form-group col-md-12" >
        <
        div class = "input-group" >
        <
        div class = "input-group-addon" >
        <
        i class = "fa fa-envelope"
        aria - hidden = "true" > < /i> <
        /div> <
        input type = "email"
        class = "form-control"
        name = "email"
        placeholder = "Email" >
        <
        /div> <
        label
        for = "email"
        generated = "true"
        class = "error" > < /label> <
        /div>

        <
        button type = "submit"
        class = "btn btn-default price-btn hvr-sweep-to-right" > SUBMIT < /button> <
        /form>

        <
        /div> <
        /div><!-- /.modal - content -->
        <
        /div><!-- /.modal - dialog-- >
        <
        /div>

        <!-- ============================================= -->


        <!-- ================ Video popup ==================== -->
        <
        div class = "modal fade in"
        tabindex = "-1"
        role = "dialog"
        id = "video-popup"
        data - backdrop = "static"
        data - keyboard = "false" >
        <
        div class = "modal-dialog"
        role = "document" >
        <
        div class = "modal-content" >
        <
        div class = "modal-header" >
        <
        button type = "button"
        class = "close"
        data - dismiss = "modal"
        aria - label = "Close" >
        <
        span aria - hidden = "true" > × < /span> <
        /button> <
        h4 class = "modal-title" > Virtual Tour < /h4> <
        /div> <
        div class = "modal-body" >
        <
        p > Please Enter Your Details To Experience the Smartcode Gold class Virtual Tour < /p> <
        form id = "video-form"
        action = "thank-you.php"
        name = "video-form"
        method = "POST"
        novalidate = "novalidate"
        onsubmit = "return save_landing_pageinfo('video-form');" >
        <
        div class = "form-group col-md-12" >
        <
        div class = "input-group" >
        <
        div class = "input-group-addon" >
        <
        i class = "fa fa-user form-ico"
        aria - hidden = "true" > < /i> <
        /div> <
        input type = "text"
        class = "form-control"
        name = "fname"
        placeholder = "Name" >
        <
        input type = "hidden"
        name = "source"
        value = "Virtual Tour" >
        <
        /div> <
        label
        for = "fname"
        generated = "true"
        class = "error" > < /label> <
        /div> <
        div class = "form-group col-md-12" >
        <
        div class = "input-group" >
        <
        div class = "input-group-addon" >
        <
        i class = "fa fa-mobile form-ico"
        aria - hidden = "true" > < /i> <
        /div> <
        input type = "number"
        class = "form-control"
        name = "mobile"
        placeholder = "Mobile" >
        <
        /div> <
        label
        for = "mobile"
        generated = "true"
        class = "error" > < /label> <
        /div>

        <
        div class = "form-group col-md-12" >
        <
        div class = "input-group" >
        <
        div class = "input-group-addon" >
        <
        i class = "fa fa-envelope"
        aria - hidden = "true" > < /i> <
        /div> <
        input type = "email"
        class = "form-control"
        name = "email"
        placeholder = "Email" >
        <
        /div> <
        label
        for = "email"
        generated = "true"
        class = "error" > < /label> <
        /div>

        <
        button type = "submit"
        class = "btn btn-default price-btn hvr-sweep-to-right" > SUBMIT < /button> <
        /form>

        <
        /div> <
        /div><!-- /.modal - content -->
        <
        /div><!-- /.modal - dialog-- >
        <
        /div>

        <!-- ============================================= -->

        <
        div class = "modal fade in"
        tabindex = "-1"
        role = "dialog"
        id = "download1"
        data - backdrop = "static"
        data - keyboard = "false" >
        <
        div class = "modal-dialog"
        role = "document" >
        <
        div class = "modal-content" >
        <
        div class = "modal-header" >
        <
        h4 class = "modal-title" > Download Brochure < /h4> <
        button type = "button"
        class = "close"
        data - dismiss = "modal"
        aria - label = "Close" > < span aria - hidden = "true" > × < /span></button >


        <
        /div> <
        div class = "modal-body" >
        <
        p > Please enter the details below to download brochure. < /p> <
        form id = "download-brochure"
        action = "thank-you.php"
        name = "download-brochure"
        method = "POST"
        onsubmit = "return save_landing_pageinfo('download-brochure');" >
        <
        div class = "form-group col-md-12 pd" >
        <
        div class = "input-group" >
        <
        div class = "input-group-addon" > < i class = "fa fa-user form-ico"
        aria - hidden = "true" > < /i> <
        /div> <
        input type = "text"
        class = "form-control"
        name = "fname"
        placeholder = "Name" >
        <
        input type = "hidden"
        name = "source"
        value = "Download Brochure"
        id = "source" >
        <
        /div> <
        label
        for = "fname"
        generated = "true"
        class = "error" > < /label> <
        /div> <
        div class = "form-group col-md-12 pd" >
        <
        div class = "input-group" >
        <
        div class = "input-group-addon" > < i class = "fa fa-mobile form-ico"
        aria - hidden = "true" > < /i> <
        /div> <
        input type = "number"
        class = "form-control"
        placeholder = "Phone*"
        name = "mobile"
        required >
        <
        /div> <
        label
        for = "mobile"
        generated = "true"
        class = "error" > < /label> <
        /div>

        <
        div class = "form-group col-md-12 pd" >
        <
        div class = "input-group" >
        <
        div class = "input-group-addon" > < i class = "fa fa-envelope"
        aria - hidden = "true" > < /i> <
        /div> <
        input type = "email"
        class = "form-control"
        name = "email"
        placeholder = "Email" >
        <
        /div> <
        label
        for = "email"
        generated = "true"
        class = "error" > < /label> <
        /div>




        <
        button type = "submit"
        class = "btn btn-default price-btn"
        value = "proceed" > SUBMIT < /button> <
        /form> <
        /div> <
        /div><!-- /.modal - content -->
        <
        /div><!-- /.modal - dialog-- >
        <
        /div>


        <
        a id = "layoutpdf1"
        style = "display: none;"
        href = "images/Smartcode Gold class Brochure.pdf"
        download >
        <
        /a>

        <!-- -======================  Disclaimer PopUp  -->


        <
        div class = "modal fade in"
        tabindex = "-1"
        role = "dialog"
        id = "floorplan"
        data - backdrop = "static"
        data - keyboard = "false" >
        <
        div class = "modal-dialog"
        role = "document" >
        <
        div class = "modal-content" >
        <
        div class = "modal-header" >
        <
        h4 class = "modal-title" > Download Floor Plan < /h4> <
        button type = "button"
        class = "close"
        data - dismiss = "modal"
        aria - label = "Close" > < span aria - hidden = "true" > × < /span></button >


        <
        /div> <
        div class = "modal-body" >
        <
        p > Please enter the details below to download Floor Plan. < /p> <
        form id = "floor"
        action = "thank-you.php"
        name = "floor"
        method = "POST"
        onsubmit = "return save_landing_pageinfo('floor');" >
        <
        div class = "form-group col-md-12 pd" >
        <
        div class = "input-group" >
        <
        div class = "input-group-addon" > < i class = "fa fa-user form-ico"
        aria - hidden = "true" > < /i> <
        /div> <
        input type = "text"
        class = "form-control"
        name = "fname"
        placeholder = "Name" >
        <
        input type = "hidden"
        name = "source"
        value = "Floor Plan"
        id = "source" >
        <
        /div> <
        label
        for = "fname"
        generated = "true"
        class = "error" > < /label> <
        /div> <
        div class = "form-group col-md-12 pd" >
        <
        div class = "input-group" >
        <
        div class = "input-group-addon" > < i class = "fa fa-mobile form-ico"
        aria - hidden = "true" > < /i> <
        /div> <
        input type = "number"
        class = "form-control"
        placeholder = "Phone*"
        name = "mobile"
        required >
        <
        /div> <
        label
        for = "mobile"
        generated = "true"
        class = "error" > < /label> <
        /div>

        <
        div class = "form-group col-md-12 pd" >
        <
        div class = "input-group" >
        <
        div class = "input-group-addon" > < i class = "fa fa-envelope"
        aria - hidden = "true" > < /i> <
        /div> <
        input type = "email"
        class = "form-control"
        name = "email"
        placeholder = "Email" >
        <
        /div> <
        label
        for = "email"
        generated = "true"
        class = "error" > < /label> <
        /div>



        <
        button type = "submit"
        class = "btn btn-default price-btn"
        value = "proceed" > SUBMIT < /button> <
        /form> <
        /div> <
        /div><!-- /.modal - content -->
        <
        /div><!-- /.modal - dialog-- >
        <
        /div>


        <
        a id = "floor1"
        style = "display: none;"
        href = "images/Smartcode Gold class Brochure.pdf"
        download > < /a>


        <!-- -====================== offers PopUp  -->


        <
        div class = "modal fade in"
        tabindex = "-1"
        role = "dialog"
        id = "offersform"
        data - backdrop = "static"
        data - keyboard = "false" >
        <
        div class = "modal-dialog"
        role = "document" >
        <
        div class = "modal-content" >
        <
        div class = "modal-header" >
        <!--                    <h4 class="modal-title">Offer</h4>-->
        <
        button type = "button"
        class = "close"
        data - dismiss = "modal"
        aria - label = "Close" > < span aria - hidden = "true" > × < /span></button >


        <
        /div> <
        div class = "modal-body" >
        <
        p > Please enter the details below < /p> <
        form id = "offer-forms"
        action = "thank-you.php"
        name = "offer-forms"
        method = "POST"
        onsubmit = "return save_landing_pageinfo('offer-forms');" >
        <
        div class = "form-group col-md-12 pd" >
        <
        div class = "input-group" >
        <
        div class = "input-group-addon" > < i class = "fa fa-user form-ico"
        aria - hidden = "true" > < /i> <
        /div> <
        input type = "text"
        class = "form-control"
        name = "fname"
        placeholder = "Name" >
        <
        input type = "hidden"
        name = "source"
        value = "OFFER"
        id = "source" >
        <
        /div> <
        label
        for = "fname"
        generated = "true"
        class = "error" > < /label> <
        /div> <
        div class = "form-group col-md-12 pd" >
        <
        div class = "input-group" >
        <
        div class = "input-group-addon" > < i class = "fa fa-mobile form-ico"
        aria - hidden = "true" > < /i> <
        /div> <
        input type = "number"
        class = "form-control"
        placeholder = "Phone*"
        name = "mobile"
        required >
        <
        /div> <
        label
        for = "mobile"
        generated = "true"
        class = "error" > < /label> <
        /div>

        <
        div class = "form-group col-md-12 pd" >
        <
        div class = "input-group" >
        <
        div class = "input-group-addon" > < i class = "fa fa-envelope"
        aria - hidden = "true" > < /i> <
        /div> <
        input type = "email"
        class = "form-control"
        name = "email"
        placeholder = "Email" >
        <
        /div> <
        label
        for = "email"
        generated = "true"
        class = "error" > < /label> <
        /div>




        <
        button type = "submit"
        class = "btn btn-default price-btn"
        value = "proceed" > SUBMIT < /button> <
        /form> <
        /div> <
        /div><!-- /.modal - content -->
        <
        /div><!-- /.modal - dialog-- >
        <
        /div>


        <
        div class = "modal fade in"
        tabindex = "-1"
        role = "dialog"
        id = "rera-pop"
        data - backdrop = "static"
        data - keyboard = "false" >
        <
        div class = "modal-dialog modal-lg"
        role = "document" >
        <
        div class = "modal-content" >
        <
        div class = "modal-header" >
        <
        button type = "button"
        class = "close"
        data - dismiss = "modal"
        aria - label = "Close" > < span aria - hidden = "true" > × < /span></button >

        <
        h4 class = "modal-title" > Disclaimer! < /h4> <
        /div> <
        div class = "modal-body" >
        <
        p >
        GST rate as applicable and announced by the Govt.on purchase / payments of a property.The information provided in this advertisement, including all pictures, images, plans, drawings,
        amenities, dimensions, elevations, illustrations, facilities, features, specifications, other information, etc.mentioned are indicative of the kind of development that is proposed and are subject to the approval from the competent authorities
        for the under construction projects.Pictures, visuals, perspective views of the building are as per architectural drawings and the same shall be constructed subject to approvals of competent authorities and shall be in
        compliance of RERA Act and Rules and Regulations.Furniture, Fixtures, Accessories and Furnishings shown are only
        for representation and shall not be provided in the actual flat.The mentioned projects are mortgaged to respective Banks & Financial Institutions.No Objection Certificate(NOC) / permission of the mortgagee Bank would be provided
        for sale of
        flats / units / property,
        if required.The actual views are taken from the property but no particular apartment.If customer chooses
        for 10: 90 scheme i.e.the minimum upfront contribution by customer is 10 % of consideration value and 90 % shall be disbursed by financial institution.In this
        case the Developer will bear Pre - EMI on the disbursed amount
        for the period of 1(one) year or agreed period from date of booking.Any EMI scheme is subject to individual eligibility from our approved financial institution.*Terms & conditions apply in the agreement
        for sale shall be final. <
        /p>


        <
        /div> <
        div class = "modal-footer" >
        <
        button type = "button"
        class = "btn btn-default price-btn"
        data - dismiss = "modal"
        aria - label = "Close" > OK <
        /button> <
        /div> <
        /div><!-- /.modal - content-- >
        <
        /div><!-- /.modal - dialog-- >
        <
        /div>


        <
        div class = "modal fade in"
        tabindex = "-1"
        role = "dialog"
        id = "gmap"
        data - backdrop = "static"
        data - keyboard = "false" >
        <
        div class = "modal-dialog"
        role = "document" >
        <
        div class = "modal-content" >
        <
        div class = "" >
        <
        button type = "button"
        class = "close"
        data - dismiss = "modal"
        aria - label = "Close" >
        <
        span aria - hidden = "true" > × < /span> <
        /button>

        <
        /div> <
        div class = "modal-body" >
        <
        img src = "images/gallery/location/1.jpg"
        class = "img-responsive" / >
        <
        /div> <
        /div><!-- /.modal - content-- >
        <
        /div><!-- /.modal - dialog-- >
        <
        /div>

        <!-- ============================================= -->


        <!-- End Normal popup form -->
        <!--<script type="text/javascript" src="lightbox/lighbox.js"></script>-->
        <
        script src = "js/bootstrap.min.js"
        type = "text/javascript" > < /script> <
        script src = "js/cookie.js" > < /script>
        <!-- <script src="js/wow.js"></script> -->
        <!-- waybeolib -->
        <
        script type = "text/javascript"
        src = "http://js.waybeo.com/v0.1-beta2/waybeo.min.js" > < /script> <
        script type = "text/javascript"
        src = "waybeolib/js/intlTelInput.min.js" > < /script> <
        script type = "text/javascript"
        src = "waybeolib/js/normalpopup-onclick.js" > < /script>
        <!-- waybeolib -->

        <
        script src = "owlcarousel/owl.carousel.min.js" > < /script>

        <
        script src = "js/jquery.validate.js" > < /script> <
        script src = "js/mobilevalidate.js" > < /script>

        <
        script src = "js/popout.js" > < /script>

        <
        script src = "https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js" > < /script>

        <
        script src = "https://owlcarousel2.github.io/OwlCarousel2/assets/owlcarousel/owl.carousel.js" > < /script>


        <
        script >
        jQuery(document).ready(function($) {
            $('[data-fancybox="general"]').fancybox({

                //slide effec zoom-in-out
                transitionEffect: "slide",
                loop: false,

                buttons: [
                    //'slideShow',
                    //'share',
                    'zoom',
                    'fullScreen',
                    'close'
                    //'download'
                ],
                thumbs: {
                    autoStart: false
                }
            });
            $('[data-fancybox="interior"]').fancybox({

                //slide effec zoom-in-out
                transitionEffect: "slide",
                loop: false,

                buttons: [
                    //'slideShow',
                    //'share',
                    'zoom',
                    'fullScreen',
                    'close'
                    //'download'
                ],
                thumbs: {
                    autoStart: false
                }
            });
            $('[data-fancybox="floorplan"]').fancybox({

                //slide effec zoom-in-out
                transitionEffect: "slide",
                loop: false,

                buttons: [
                    //'slideShow',
                    //'share',
                    'zoom',
                    'fullScreen',
                    'close'
                    //'download'
                ],
                thumbs: {
                    autoStart: false
                }
            });
            $('[data-fancybox="masterplan"]').fancybox({

                //slide effec zoom-in-out
                transitionEffect: "slide",
                loop: false,

                buttons: [
                    //'slideShow',
                    //'share',
                    'zoom',
                    'fullScreen',
                    'close'
                    //'download'
                ],
                thumbs: {
                    autoStart: false
                }
            });
        }); <
        /script>

        <
        script >
        $('.moreless-button').click(function() {
            $('.moretext').slideToggle();
            if ($('.moreless-button').text() == "Read more") {
                $(this).text("Read less")
            } else {
                $(this).text("Read more")
            }
        });

        $('.moreless-button1').click(function() {
            $('.moretext1').slideToggle();
            if ($('.moreless-button1').text() == "Read more") {
                $(this).text("Read less")
            } else {
                $(this).text("Read more")
            }
        }); <
        /script>

        <
        script type = "text/javascript" >
        jQuery(document).ready(function($) {
            Delete_Cookie('formfilled');


            // ---------------for model only-----
            $(".price-click").click(function() {
                $('#price-model').modal('show');
            });

            $(".interested").click(function() {
                $('#interested').modal('show');
            });

            $(".i-am").click(function() {
                $('#interested').modal('show');
            });

            $(".maplink").click(function() {
                $('#gmap').modal('show');
            });

            $(".download1").click(function() {
                $('#download1').modal('show');
            });

            $(".floor").click(function() {
                $('#floorplan').modal('show');
            });

            $(".offerss").click(function() {
                $('#offersform').modal('show');
            });

            $(".video-popup").click(function() {
                $('#video-popup').modal('show');
            });

            //        setTimeout(function () {
            //            $('#rera-pop').modal('show');
            //        }, 2000);


        }); <
        /script>

        <
        script >
        $('.owl-carousel').owlCarousel({
            items: 3,
            loop: true,
            margin: 25,
            autoplay: false,
            // autoplayTimeout: 2000,
            // autoplayHoverPause: true,
            nav: true,
            dots: false,
            navText: ['<span class="fas fa-chevron-left fa-3x"></span>',
                '<span class="fas fa-chevron-right fa-3x"></span>'
            ],
            responsive: {
                0: {
                    items: 1
                },
                768: {
                    items: 3
                }
            }
        }) <
        /script>


        <
        script >
        jQuery(document).ready(function($) {
            // Add smooth scrolling to all links
            $(".m-link").on('click', function(event) {

                // Make sure this.hash has a value before overriding default behavior
                if (this.hash !== "") {
                    // Prevent default anchor click behavior
                    event.preventDefault();

                    // Store hash
                    var hash = this.hash;

                    // Using jQuery's animate() method to add smooth page scroll
                    // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area

                    $('html, body').animate({
                        scrollTop: $(hash).offset().top
                    }, 800, function() {
                        // Add hash (#) to URL when done scrolling (default click behavior)
                        // window.location.hash = hash;
                    });
                } // End if
            });

            $('.navbar-nav li').on('click', function() {
                $('.navbar-nav li.active').removeClass('active');
                $(this).addClass('active');
            });
            $(document).on('click', '.navbar-collapse.in', function(e) {
                if ($(e.target).is('a') && ($(e.target).attr('class') != 'dropdown-toggle')) {
                    $(this).collapse('hide');
                }
            });
        }); <
        /script>

        <
        script >
        $(window).scroll(function() {
            var scroll = $(window).scrollTop();

            if (scroll >= 75) {
                $("#hide-menu").addClass("fixHeader");
            } else {
                $("#hide-menu").removeClass("fixHeader");
            }
        }); <
        /script>

        <
        script >
        $(document).ready(function() {
            var $panels = $('.panel-collapse');

            $panels.on('show.bs.collapse', function() {
                $panels.not(this).collapse('hide');
            });
        }); <
        /script>


        <
        script type = "text/javascript" >
        function save_landing_pageinfo(elm) {
            jQuery('#' + elm + ' input[type=submit], #' + elm + ' button').prop('disabled', true);
            setTimeout(function() {
                jQuery('#' + elm + ' input[type=submit], #' + elm + ' button').prop('disabled', false);
            }, 5000);
            var name = jQuery('#' + elm + ' input[name="fname"]').val();
            var mobileno = jQuery('#' + elm + ' input[name="mobile"]').val();
            var emailid = jQuery('#' + elm + ' input[name="email"]').val();
            var message = jQuery('#' + elm + ' textarea[name="message"]').val();
            var conf = jQuery('#' + elm + ' select[name="conf"]').val();
            var fsource = jQuery('#' + elm + ' input[name="source"]').val();
            var current_url = location.hostname;

            if (name == "") {
                //alert("Please Enter Your Name");
                return false;
            }

            mobileno = mobileno.replace(/[^0-9]/g, '');
            if (mobileno.length != 10) {
                //alert("Please Enter 10 Digit Mobile Number");
                return false;
            }


            if (conf == "") {
                //alert("Please Enter Your Name");
                return false;
            }
            if (elm == 'price-popup') {
                emailid = "";
            } else if (elm == 'main-popup') {
                emailid = "";
            } else {
                var atpos = emailid.indexOf("@");
                var dotpos = emailid.lastIndexOf(".");
                if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= emailid.length) {
                    return false;
                }
            }

            if (message == undefined) {
                message = "";
            }


            if (elm == 'download-brochure') {
                document.getElementById('layoutpdf1').click();
            }


            if (elm == 'floor') {
                document.getElementById('floor1').click();
            }


            var _phone = mobileno;

            if (name != "" && mobileno != "") {
                $("#pageloader").fadeIn();
                return true;
            }




            return false;
        }

        function submitForm(elm) {
            document.createElement('form').submit.call(document.getElementById(elm));
        } <
        /script>


        <
        /body>

        <
        /html>